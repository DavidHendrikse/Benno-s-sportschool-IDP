<?php
$title = "Home";
$content = "Wat een geweldig project";

include 'Template.php';

?>

